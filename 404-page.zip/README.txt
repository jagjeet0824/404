A Pen created at CodePen.io. You can find this one at https://codepen.io/kborling/pen/QwbKEe.

 Here's a 404 error page that I created for my portfolio. This is just a mock-up, but feel free to fork and make it into your own 404 page!